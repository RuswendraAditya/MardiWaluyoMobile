package mardiwaluyo.com.mardiwaluyomobile.main.info;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import mardiwaluyo.com.mardiwaluyomobile.R;

public class JamBesukActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jam_besuk);
    }
}
