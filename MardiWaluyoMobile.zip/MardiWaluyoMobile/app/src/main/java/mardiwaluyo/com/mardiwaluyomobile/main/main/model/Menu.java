package mardiwaluyo.com.mardiwaluyomobile.main.main.model;

/**
 * Created by Wendra on 10/11/2017.
 */

public class Menu {
    public int id;
    public String text;
    public int image;

    public Menu(int id, String text, int image) {
        this.id = id;
        this.text = text;
        this.image = image;

    }

}
