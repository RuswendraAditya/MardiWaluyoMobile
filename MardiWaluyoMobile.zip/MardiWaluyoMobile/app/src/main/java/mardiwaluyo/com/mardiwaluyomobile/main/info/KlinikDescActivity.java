package bethesda.com.bethesdahospitalmobile.main.info;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import bethesda.com.bethesdahospitalmobile.R;
public class KlinikDescActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_klinik_desc);
    }
}
