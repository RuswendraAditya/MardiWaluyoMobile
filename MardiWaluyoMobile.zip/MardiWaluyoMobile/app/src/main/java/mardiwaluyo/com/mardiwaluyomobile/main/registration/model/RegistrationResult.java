package mardiwaluyo.com.mardiwaluyomobile.main.registration.model;

/**
 * Created by Wendra on 10/17/2017.
 */

public class RegistrationResult {
    private String tglReg;
    private String jamReg;
    private String noRm;
    private String noRegj;
    private String namaPasien;
    private String kodeKlinik;
    private String namaKlinik;
    private String kodeDokter;
    private String namaDokter;
    private String noUrutklinik;
    private String noUrutdokter;
    private String response;
    private String deskripsiResponse;

    public String getTglReg() {
        return tglReg;
    }

    public void setTglReg(String tglReg) {
        this.tglReg = tglReg;
    }


    public String getJamReg() {
        return jamReg;
    }

    public void setJamReg(String jamReg) {
        this.jamReg = jamReg;
    }


    public String getNoRm() {
        return noRm;
    }

    public void setNoRm(String noRm) {
        this.noRm = noRm;
    }

    public String getNoRegj() {
        return noRegj;
    }

    public void setNoRegj(String noRegj) {
        this.noRegj = noRegj;
    }

    public String getNamaPasien() {
        return namaPasien;
    }

    public void setNamaPasien(String namaPasien) {
        this.namaPasien = namaPasien;
    }

    public String getKodeKlinik() {
        return kodeKlinik;
    }

    public void setKodeKlinik(String kodeKlinik) {
        this.kodeKlinik = kodeKlinik;
    }

    public String getNamaKlinik() {
        return namaKlinik;
    }

    public void setNamaKlinik(String namaKlinik) {
        this.namaKlinik = namaKlinik;
    }

    public String getKodeDokter() {
        return kodeDokter;
    }

    public void setKodeDokter(String kodeDokter) {
        this.kodeDokter = kodeDokter;
    }

    public String getNamaDokter() {
        return namaDokter;
    }

    public void setNamaDokter(String namaDokter) {
        this.namaDokter = namaDokter;
    }

    public String getNoUrutklinik() {
        return noUrutklinik;
    }

    public void setNoUrutklinik(String noUrutklinik) {
        this.noUrutklinik = noUrutklinik;
    }

    public String getNoUrutdokter() {
        return noUrutdokter;
    }

    public void setNoUrutdokter(String noUrutdokter) {
        this.noUrutdokter = noUrutdokter;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getDeskripsiResponse() {
        return deskripsiResponse;
    }

    public void setDeskripsiResponse(String deskripsiResponse) {
        this.deskripsiResponse = deskripsiResponse;
    }

}
