package mardiwaluyo.com.mardiwaluyomobile.main.login.model;

/**
 * Created by Wendra on 10/9/2017.
 */

public class Login {
    private String noRM;
    private String dtglLahir;
    private String namaPasien;
    private String alamat;
    private String response;
    private String deskripsiResponse;


    public String getNoRM() {
        return noRM;
    }

    public void setNoRM(String noRM) {
        this.noRM = noRM;
    }

    public String getDtglLahir() {
        return dtglLahir;
    }

    public void setDtglLahir(String dtglLahir) {
        this.dtglLahir = dtglLahir;
    }

    public String getNamaPasien() {
        return namaPasien;
    }

    public void setNamaPasien(String namaPasien) {
        this.namaPasien = namaPasien;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getDeskripsiResponse() {
        return deskripsiResponse;
    }

    public void setDeskripsiResponse(String deskripsiResponse) {
        this.deskripsiResponse = deskripsiResponse;
    }

}
