package com.robohorse.gpversionchecker.domain;

/**
 * Created by robohorse on 06.03.16.
 */
public enum CheckingStrategy {
    ALWAYS, ONE_PER_DAY, ONE_PER_VERSION, ONE_PER_VERSION_PER_DAY
}
